<!--<div id='notifications'>&nbsp;
</div>-->
<div id='socialMediaAdvert' onmouseover="if(document.getElementById('rightsidebar').style.display=='none'){document.getElementById('rightsidebar').style.display='block';}">
<img src='images/fb_logo.png' width='40px' border='0'/>
<div style="font-size:2px;">&nbsp;</div>
<img src='images/g+_logo.png' width='40px' border='0'/>
<div style="font-size:2px;">&nbsp;</div>
<img src='images/twitter.png' width='40px' border='0'/>
</div>